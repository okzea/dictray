const { Gio, GLib, GObject, St, Clutter } = imports.gi
const ByteArray = imports.byteArray
const Main = imports.ui.main
const PanelMenu = imports.ui.panelMenu
const PopupMenu = imports.ui.popupMenu

const EXTENSION_ID = 'dictray-gnome-panel@okzea'
const PANEL_DIR = `${GLib.get_user_config_dir()}/dictray/gnome-panel`
const STATUS_FILE = `${PANEL_DIR}/status.json`
const COMMAND_FILE = `${PANEL_DIR}/command.json`
const POLL_INTERVAL_MS = 1200
const ACTIVE_PHASES = new Set(['listening', 'processing', 'transcribing', 'rewriting', 'inserting', 'pending_insert'])

let indicator = null

function compactText(value, limit = 72) {
  const text = String(value || '').replace(/\s+/g, ' ').trim()
  if (text.length <= limit) {
    return text
  }
  return `${text.slice(0, Math.max(0, limit - 3)).trim()}...`
}

function readStatusFile() {
  const file = Gio.File.new_for_path(STATUS_FILE)
  if (!file.query_exists(null)) {
    return null
  }

  try {
    const [ok, bytes] = file.load_contents(null)
    if (!ok || !bytes) {
      return null
    }
    const payload = JSON.parse(ByteArray.toString(bytes))
    return payload && typeof payload === 'object' ? payload : null
  } catch {
    return null
  }
}

function writeCommand(action) {
  const payload = {
    action,
    requestedAt: Date.now()
  }

  try {
    const file = Gio.File.new_for_path(COMMAND_FILE)
    const parent = file.get_parent()
    try {
      parent.make_directory_with_parents(null)
    } catch {
    }
    file.replace_contents(
      ByteArray.fromString(JSON.stringify(payload)),
      null,
      false,
      Gio.FileCreateFlags.REPLACE_DESTINATION,
      null
    )
  } catch (error) {
    logError(error)
  }
}

const DicTrayIndicator = GObject.registerClass(
  class DicTrayIndicator extends PanelMenu.Button {
    _init() {
      super._init(0.0, 'DicTray')
      this._state = null

      const box = new St.BoxLayout({
        x_expand: false,
        y_expand: false,
        y_align: Clutter.ActorAlign.CENTER
      })
      this._statusDot = new St.Label({
        text: '○',
        y_align: Clutter.ActorAlign.CENTER
      })
      this._title = new St.Label({
        text: ' DicTray',
        y_align: Clutter.ActorAlign.CENTER,
        style_class: 'dictray-panel-label'
      })
      this._statusDot.style = 'margin-right: 4px; color: #9aa0a6;'
      box.add_child(this._statusDot)
      box.add_child(this._title)
      this.add_child(box)

      this._statusItem = new PopupMenu.PopupMenuItem('Status: waiting for app...', { reactive: false })
      this._targetItem = new PopupMenu.PopupMenuItem('Target: unavailable', { reactive: false })
      this._noteItem = new PopupMenu.PopupMenuItem('Note: unavailable', { reactive: false })
      this._errorItem = new PopupMenu.PopupMenuItem('Error: none', { reactive: false })
      this._toggleItem = new PopupMenu.PopupMenuItem('Start Dictation')
      this._toggleItem.connect('activate', () => {
        writeCommand('toggle')
      })

      this.menu.addMenuItem(this._statusItem)
      this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem())
      this.menu.addMenuItem(new PopupMenu.PopupMenuItem('Dictation', { reactive: false }))
      this.menu.addMenuItem(this._toggleItem)
      this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem())
      this.menu.addMenuItem(this._targetItem)
      this.menu.addMenuItem(this._noteItem)
      this.menu.addMenuItem(this._errorItem)

      this._pollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, POLL_INTERVAL_MS, () => {
        this._syncFromStatus()
        return true
      })

      this._applyMissingState()
    }

    _syncFromStatus() {
      const next = readStatusFile()
      if (!next) {
        this._applyMissingState()
        return
      }

      this._state = next
      const phase = String(next.phase || '').trim() || 'idle'
      const phaseLabel = String(next.phaseLabel || phase).trim() || 'unknown'
      const dictating = ACTIVE_PHASES.has(phase)
      this._statusItem.label.text = `Status: ${phaseLabel}`
      this._targetItem.label.text = `Target: ${compactText(next.targetWindow || 'none', 72)}`
      this._noteItem.label.text = `Note: ${compactText(next.note || 'none', 72)}`
      this._errorItem.label.text = `Error: ${compactText(next.error || 'none', 72)}`
      this._toggleItem.label.text = dictating ? 'Stop Dictation' : 'Start Dictation'
      this._toggleItem.setSensitive(true)
      this._statusDot.text = dictating ? '●' : '○'
      this._statusDot.style = dictating
        ? 'margin-right: 4px; color: #7ee787;'
        : 'margin-right: 4px; color: #9aa0a6;'
      this._title.text = ` DicTray (${String(next.hotkey || 'shortcut').trim()})`
    }

    _applyMissingState() {
      this._statusItem.label.text = 'Status: waiting for app...'
      this._targetItem.label.text = 'Target: unavailable'
      this._noteItem.label.text = 'Note: unavailable'
      this._errorItem.label.text = 'Error: none'
      this._toggleItem.label.text = 'Start Dictation'
      this._toggleItem.setSensitive(false)
      this._statusDot.text = '○'
      this._statusDot.style = 'margin-right: 4px; color: #9aa0a6;'
      this._title.text = ' DicTray'
      this._state = null
    }

    destroy() {
      if (this._pollId) {
        GLib.source_remove(this._pollId)
        this._pollId = null
      }
      super.destroy()
    }
  }
)

function init() {}

function enable() {
  if (indicator) {
    indicator.destroy()
  }
  indicator = new DicTrayIndicator()
  Main.panel.addToStatusArea(EXTENSION_ID, indicator, 1, 'right')
}

function disable() {
  if (!indicator) {
    return
  }
  indicator.destroy()
  indicator = null
}
